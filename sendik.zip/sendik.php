<?php
$user = "waitlessbuzz";
$pass = "Waitless12";
$service = "TRANS";

$itime=10;
$imin=00;
$smin=15;
$tmin=30;
$fmin=45;
$AM="AM";
$PM="PM";

$x="$itime:$imin $AM";
$y="$itime:$smin $AM";
$z="$itime:$tmin $AM";
$w="$itime:$fmin $AM";

$message = urlencode("test message 1");

$dmessage = urldecode($message);

switch($dmessage)
{
case "test message 1": $message=urlencode($x);
                      break;
case "test message 2": $message=urlencode($y);
                      break;
case "test message 3": $message=urlencode($z);
                      break;
case "test message 4": $message=urlencode("$w");
                      break;

}
# Add your Mobile number to test
$to2 = "9986414476";  

$sender = "WTLESS";

$url2 = "https://aikonsms.co.in/control/smsapi.php?user_name=$user&password=$pass&sender_id=$sender&service=$service&mobile_no=$to2&message=$message&method=send_sms";
$ret2 = file_get_contents($url2);
echo $ret2;
?>

